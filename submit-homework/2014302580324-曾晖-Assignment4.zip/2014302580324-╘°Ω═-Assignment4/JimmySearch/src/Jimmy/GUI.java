package Jimmy;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class GUI extends JFrame implements ActionListener,ItemListener
{
	JButton b1;
	static JTextField textField;
	JTextArea textArea;
	JRadioButton radioButton1;
	JRadioButton radioButton2;
	JRadioButton radioButton3;
	JRadioButton radioButton4;
	JRadioButton radioButton5;
	static int flag = 0;
	
	public GUI() 
	{
		// TODO Auto-generated constructor stub
		
		b1 = new JButton("Search");
		b1.setFont(new Font("Serif",Font.ITALIC, 14));
		b1.setBackground(Color.YELLOW);
		b1.addActionListener(this);
		textField = new JTextField("����������Ҫ��������Ϣ",20);
		textField.setFont(new Font("Serif",Font.ITALIC, 14));
		textField.setBackground(Color.GRAY);
		textField.addActionListener(this);
		textArea = new JTextArea(10,30);
		textArea.setBackground(Color.GRAY);
		textArea.setEditable(false);
		textArea.setFont(new Font("Serif", Font.PLAIN, 14));
		radioButton1 = new JRadioButton("Name");
		radioButton2 = new JRadioButton("EducationBackground");
		radioButton3 = new JRadioButton("ResearchInterests");
		radioButton4 = new JRadioButton("Email");
		radioButton5 = new JRadioButton("Phone");
		radioButton1.addItemListener(this);
		radioButton2.addItemListener(this);
		radioButton3.addItemListener(this);
		radioButton4.addItemListener(this);
		radioButton5.addItemListener(this);
		
		JPanel panel = new JPanel(new FlowLayout());
		JPanel panel2 = new JPanel(new FlowLayout());
		JPanel panel3 = new JPanel(new GridLayout(3,2));
		
		panel3.add(radioButton1);
		panel3.add(radioButton2);
		panel3.add(radioButton3);
		panel3.add(radioButton4);
		panel3.add(radioButton5);
		Box box = Box.createHorizontalBox();
		panel.add(textField);
		panel.add(b1);
		panel2.add(panel);
		panel2.add(panel3);
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		box.add(scrollPane);
		panel2.add(box);
		add(panel2);
		setTitle("WPI��ʦ��Ϣ����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400, 400);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent event) 
	{
		// TODO Auto-generated method stub
		if(event.getActionCommand() == "Search")
		{
			textArea.setText("");
			if(flag == 0)
			{
				JOptionPane.showMessageDialog(null, "��ѡ����Ҫ��������Ŀ","Warning", 0);
			}
			handleButton();
		}
		
		
	}
	
	public void handleButton() 
	{
		if(textField.getText().equals("")||textField.getText().equals("����������Ҫ��������Ϣ")) 
		{
			JOptionPane.showMessageDialog(null, "����������Ҫ��������Ϣ","Warning", 0);
			return;
		}
		else
		{
			String[] str = ConnectSQL.getText(textField.getText());
			for(int i = 0;i<str.length;i++)
			textArea.setText(textArea.getText()+str[i]);
		}
	}
	@Override
	public void itemStateChanged(ItemEvent e) 
	{
		// TODO Auto-generated method stub
		if(radioButton1.isSelected())
		{
			flag = 1;
		}
		
		if (radioButton2.isSelected()) 
		{
			flag = 2;
		}
		
		if (radioButton3.isSelected()) 
		{
			flag = 3;
		}
		
		if (radioButton4.isSelected()) 
		{
			flag = 4;
		}
		
		if (radioButton5.isSelected()) 
		{
			flag = 5;
		}
	}
	
	

}
