package Jimmy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;;


public class ConnectSQL 
{

	public static String[] getText(String s)
	{
	ResultSet resultSet = null;
	Statement statement = null;
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	int i = 0;
	String[] text = new String[100];
	String[] text1 = new String[100];
	double[] arr = new double[100];
	try 
	{
		Class.forName("com.mysql.jdbc.Driver"); 
		connection = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/2014302580324_professor_info?user=root&password=5511332*ss");
		statement = connection.createStatement();
		switch (GUI.flag) 
		{
		case 1:
			preparedStatement = connection.prepareStatement("SELECT * FROM professor_info WHERE name LIKE ?");
			break;
		case 2:
			preparedStatement = connection.prepareStatement("SELECT * FROM professor_info WHERE educationBackground LIKE ?");
			break;
		case 3:
			preparedStatement = connection.prepareStatement("SELECT * FROM professor_info WHERE researchInterests LIKE ?");
			break;
		case 4:
			preparedStatement = connection.prepareStatement("SELECT * FROM professor_info WHERE email LIKE ?");
			break;
		case 5:
			preparedStatement = connection.prepareStatement("SELECT * FROM professor_info WHERE phone LIKE ?");
			break;
		default:
			break;
		}
		
		preparedStatement.setString(1,"%"+s+"%");
		resultSet = preparedStatement.executeQuery();
		
		while(resultSet.next())
		{
			
			text1[i] = (splitN(resultSet.getString(1))
	           + splitN(resultSet.getString(2))
	           + splitN(resultSet.getString(3))
	           + splitN(resultSet.getString(4))
	           +splitN(resultSet.getString(5))).toLowerCase().trim();
			text[i] = "Name:"+resultSet.getString(1)
			           +"\neducationBackground:"+resultSet.getString(2)
			           +"\nresearchInterests:"+resultSet.getString(3)
			           +"\nemail:"+resultSet.getString(4)
			           +"\nphone:"+resultSet.getString(5)+"\n";
			arr[i] = getTf(GUI.textField.getText(), text1[i]);
			i++;
		}
		
		sort(arr,text);
		
	}catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}catch(SQLException e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(resultSet!=null)
			{
				resultSet.close();
				resultSet = null;
			}
			if(preparedStatement!=null)
			{
				preparedStatement.close();
				preparedStatement = null;
			}
			if(connection!=null)
			{
				connection.close();
				connection = null;
			}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	return text;//���ض�Ӧ��DANME;
	}
	
	
	private static double getTf(String s,String text1) 
	{
		double tf;
		String[] sepKeyw = s.split(" ");
		String string = text1;
		String[] sepText = text1.split(" ");
		int lenText = sepText.length;
		int c = s.split(" ").length;
		int j = 0,count = 0;
		for(int i = 0; i < c;i ++)
		{
			if(!string.contains(sepKeyw[i]))
				j++;
			if(j == c)
				return 0;
		}
		for(int i=0;i<c;i++)
		{
			
			for(int n=0;n<lenText;n++)
			{
				if(!sepKeyw[i].isEmpty()&&!sepText[n].isEmpty())
				{
					if(sepKeyw[i].contains(sepText[n])|sepText[n].contains(sepKeyw[i]))
					{
						count++;
					}
				}
			}
		}
		
		tf = ((double)count)/ ((double)lenText);
		return tf;
	}
		
	public static String splitN(String s)
	{
		String string[] = s.split("\n");
		String c = "";
		for(String a:string)
		{
			c = c + a + " ";
		}
		return c.trim();
	}
	
	    public static void sort(double[] a,String[] b)
	    {
	        String temp = "";
	        for (int i = a.length - 1; i > 0; --i)
	        {
	            for (int j = 0; j < i; ++j)
	            {
	                if (a[j + 1] < a[j])
	                {
	                    temp = b[j];
	                    b[j] = b[j + 1];
	                    b[j + 1] = temp;
	                }
	            }
	        }
	    }
	
}
