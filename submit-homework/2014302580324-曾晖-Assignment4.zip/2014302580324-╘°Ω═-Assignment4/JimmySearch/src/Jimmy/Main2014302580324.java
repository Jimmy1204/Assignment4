package Jimmy;

import java.awt.Color;


public class Main2014302580324
{
	public static void main(String[] args) 
	{
		
		GUI gui = new GUI();
		gui.getContentPane().setBackground(Color.WHITE);
	}
}
